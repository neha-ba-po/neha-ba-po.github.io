# Neha Choudhary — Portfolio

Static portfolio website for GitHub Pages.

## Publish on GitHub Pages
1. Create a GitHub repository named `yourusername.github.io`.
2. Upload `index.html` and `style.css` to the repository root.
3. In **Settings → Pages**, choose **Deploy from a branch**, select `main` and `/root`.
4. Your site will be available at `https://yourusername.github.io/`.

The site is intentionally static: no server, database, paid hosting or build step is required.
